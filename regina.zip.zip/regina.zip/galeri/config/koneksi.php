<?php
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'galeri';

$koneksi = mysqli_connect($hostname, $userdb, $passdb, $namedb);


?>