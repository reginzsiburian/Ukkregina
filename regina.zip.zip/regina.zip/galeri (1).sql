-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 25 Mar 2024 pada 05.39
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `galeri`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `album`
--

CREATE TABLE `album` (
  `albumid` int(11) NOT NULL,
  `namaalbum` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `tanggaldibuat` date NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `album`
--

INSERT INTO `album` (`albumid`, `namaalbum`, `deskripsi`, `tanggaldibuat`, `userid`) VALUES
(11, 'Sky', '\"Jika harus melepasmu, aku ingin melepasmu baik-baik. Seperti awan yang melepas hujan.\"', '2024-03-19', 3),
(13, 'Picnik', 'bagian dari tamasya, terutama di lingkungan yang indah, seperti taman, tepi danau, atau tempat lain yang memberikan pemandangan menarik', '2024-03-19', 3),
(15, 'Makanan', 'Lezattt', '2024-03-21', 3),
(16, 'Minuman', 'Segar', '2024-03-21', 3),
(17, 'Makanan', 'LLL                            ', '2024-03-24', 6),
(19, 'Minuman', 'll', '2024-03-22', 6),
(20, 'Picnik', 'kk', '2024-03-22', 6),
(21, 'bunga', 'mm', '2024-03-22', 6),
(23, 'Koleksi Mobil', 'moibill', '2024-03-24', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `dislikefoto`
--

CREATE TABLE `dislikefoto` (
  `dislikeid` int(11) NOT NULL,
  `fotoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `tanggallike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `dislikefoto`
--

INSERT INTO `dislikefoto` (`dislikeid`, `fotoid`, `userid`, `tanggallike`) VALUES
(32, 16, 4, '2024-03-21'),
(33, 27, 4, '2024-03-21'),
(34, 25, 4, '2024-03-21'),
(35, 28, 4, '2024-03-21'),
(36, 18, 4, '2024-03-21'),
(37, 26, 4, '2024-03-21'),
(38, 16, 3, '2024-03-22'),
(39, 17, 3, '2024-03-22'),
(40, 18, 3, '2024-03-22'),
(41, 27, 3, '2024-03-22'),
(42, 28, 3, '2024-03-22'),
(43, 25, 3, '2024-03-22'),
(44, 15, 3, '2024-03-22'),
(45, 26, 3, '2024-03-22'),
(46, 16, 6, '2024-03-22'),
(47, 15, 6, '2024-03-22'),
(48, 17, 6, '2024-03-22'),
(49, 31, 6, '2024-03-22'),
(50, 32, 6, '2024-03-22'),
(51, 27, 6, '2024-03-22'),
(52, 33, 6, '2024-03-22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `foto`
--

CREATE TABLE `foto` (
  `fotoid` int(11) NOT NULL,
  `judulfoto` varchar(255) NOT NULL,
  `deskripsifoto` text NOT NULL,
  `tanggalunggah` date NOT NULL,
  `lokasifile` varchar(255) NOT NULL,
  `albumid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `foto`
--

INSERT INTO `foto` (`fotoid`, `judulfoto`, `deskripsifoto`, `tanggalunggah`, `lokasifile`, `albumid`, `userid`) VALUES
(15, 'Sky', '\"Jika harus melepasmu, aku ingin melepasmu baik-baik. Seperti awan yang melepas hujan.\"', '2024-03-19', '1826476193-WhatsApp Image 2024-03-19 at 22.04.44_2068dad3.jpg', 11, 3),
(16, 'Sky', '\"Ada langkah yang berbisik pelan, menyatakan rindu dari negeri atas awan.\"', '2024-03-19', '35772222-WhatsApp Image 2024-03-19 at 22.07.34_e126e1a1.jpg', 11, 3),
(17, 'Picnik', 'bagian dari tamasya, terutama di lingkungan yang indah, seperti taman, tepi danau, atau tempat lain yang memberikan pemandangan menarik', '2024-03-19', '1358102004-WhatsApp Image 2024-03-19 at 22.29.45_18129a00.jpg', 13, 3),
(18, 'Picnik', 'bagian dari tamasya, terutama di lingkungan yang indah, seperti taman, tepi danau, atau tempat lain yang memberikan pemandangan menarik', '2024-03-19', '1435628016-WhatsApp Image 2024-03-19 at 22.29.46_108cdb51.jpg', 13, 3),
(25, 'Ayam Penyet', '..', '2024-03-21', '1055378331-ayam-geprek.png', 15, 3),
(26, 'Empek-Empek', '..', '2024-03-21', '1758072132-049176000_1663743756-crunchy-g3d878b7c3_1920.webp', 15, 3),
(27, 'ShuShu', 'Minuman seger khas korea', '2024-03-21', '1116647778-minuman_kekinian_dango_shushu_798f45a780_Olu6yUuYak.jfif', 16, 3),
(28, 'Teh Manis Dingin', 'Seger', '2024-03-21', '739091912-download.jpeg', 16, 3),
(29, 'Ayam Penyet', 'LLLL', '2024-03-22', '2056078127-ayam-geprek.png', 17, 6),
(30, 'Teh Manis Dingin', 'rrr', '2024-03-22', '343740859-download.jpeg', 19, 6),
(31, 'Picnik', 'rrr', '2024-03-22', '323242873-WhatsApp Image 2024-03-19 at 22.29.46_108cdb51.jpg', 20, 6),
(32, 'Bunga', 'mm', '2024-03-22', '2054774296-WhatsApp Image 2024-03-19 at 22.07.34_e126e1a1.jpg', 21, 6),
(33, 'Mobil', 'll', '2024-03-22', '1417892745-logo icon.jpg', 20, 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `komentarid` int(11) NOT NULL,
  `fotoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `isikomentar` text NOT NULL,
  `tanggalkomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `komentarfoto`
--

INSERT INTO `komentarfoto` (`komentarid`, `fotoid`, `userid`, `isikomentar`, `tanggalkomentar`) VALUES
(9, 15, 4, 'cantik banget pemandangannya', '2024-03-21'),
(10, 17, 4, 'Indah banget', '2024-03-21'),
(11, 18, 4, 'Salfok sama makanannyaa ', '2024-03-21'),
(12, 27, 4, 'segeerrrrrr', '2024-03-21'),
(13, 28, 4, 'lagi puasa liat beginiaann', '2024-03-21'),
(14, 33, 6, 'woww', '2024-03-22'),
(15, 15, 4, 'uhuyyyyyyy', '2024-03-24'),
(16, 26, 4, 'wah nampaknya enak sekaliiii, jadi pengen recook deh', '2024-03-24');

-- --------------------------------------------------------

--
-- Struktur dari tabel `likefoto`
--

CREATE TABLE `likefoto` (
  `likeid` int(11) NOT NULL,
  `fotoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `tanggallike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `likefoto`
--

INSERT INTO `likefoto` (`likeid`, `fotoid`, `userid`, `tanggallike`) VALUES
(79, 18, 3, '2024-03-19'),
(80, 17, 3, '2024-03-19'),
(81, 15, 3, '2024-03-20'),
(82, 16, 3, '2024-03-20'),
(83, 16, 4, '2024-03-21'),
(84, 15, 4, '2024-03-21'),
(85, 25, 3, '2024-03-21'),
(86, 26, 3, '2024-03-21'),
(87, 28, 3, '2024-03-21'),
(88, 27, 3, '2024-03-21'),
(89, 27, 4, '2024-03-21'),
(90, 28, 4, '2024-03-21'),
(91, 26, 4, '2024-03-21'),
(92, 25, 4, '2024-03-21'),
(93, 17, 4, '2024-03-21'),
(94, 18, 4, '2024-03-21'),
(95, 29, 6, '2024-03-22'),
(96, 31, 6, '2024-03-22'),
(97, 30, 6, '2024-03-22'),
(98, 32, 6, '2024-03-22'),
(99, 27, 6, '2024-03-22'),
(100, 18, 6, '2024-03-22'),
(101, 33, 6, '2024-03-22'),
(102, 16, 6, '2024-03-24'),
(103, 26, 6, '2024-03-24'),
(105, 15, 6, '2024-03-24'),
(106, 25, 6, '2024-03-24'),
(107, 28, 6, '2024-03-24'),
(108, 17, 6, '2024-03-24'),
(109, 33, 4, '2024-03-24'),
(110, 31, 4, '2024-03-24'),
(111, 29, 4, '2024-03-24');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `namalengkap` varchar(255) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `email`, `namalengkap`, `alamat`) VALUES
(3, 'admin\r\n', '123', 'reginaburian01@gmail.com', 'gina', 'Jl.Gaperta Ujung Gg.Cendana no.02'),
(4, 'Silvia', '202cb962ac59075b964b07152d234b70', 'silvia@gmail.com', 'silvia adinda', 'Jl.Pancur Batu'),
(5, 'acoundsecnd', '202cb962ac59075b964b07152d234b70', 'reginaburian01@gmail.com', 'secondd', 'gaperta'),
(6, 'admin', '202cb962ac59075b964b07152d234b70', 'reginaburian01@gmail.com', 'gina', 'Jl.Gaperta Ujung Gg.Cendana no.02'),
(7, 'Silvia', '202cb962ac59075b964b07152d234b70', 'aa@gmail.com', 'silvia adinda', 'Jl.Pancur Batu');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`albumid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `dislikefoto`
--
ALTER TABLE `dislikefoto`
  ADD PRIMARY KEY (`dislikeid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`fotoid`),
  ADD KEY `albumid` (`albumid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`komentarid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`likeid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `album`
--
ALTER TABLE `album`
  MODIFY `albumid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `dislikefoto`
--
ALTER TABLE `dislikefoto`
  MODIFY `dislikeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT untuk tabel `foto`
--
ALTER TABLE `foto`
  MODIFY `fotoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `komentarid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `likeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `album`
--
ALTER TABLE `album`
  ADD CONSTRAINT `album_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD CONSTRAINT `foto_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `foto_ibfk_2` FOREIGN KEY (`albumid`) REFERENCES `album` (`albumid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD CONSTRAINT `komentarfoto_ibfk_1` FOREIGN KEY (`fotoid`) REFERENCES `foto` (`fotoid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `komentarfoto_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD CONSTRAINT `likefoto_ibfk_1` FOREIGN KEY (`fotoid`) REFERENCES `foto` (`fotoid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `likefoto_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
